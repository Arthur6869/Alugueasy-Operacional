# Alugueasy MCP Server

Servidor MCP que expõe o codebase do Alugueasy para agentes de IA (Claude Code, Claude API).
Permite que IAs leiam, analisem e melhorem o sistema de gestão de tarefas.

---

## Setup em 3 passos

### 1. Instalar dependências

```bash
# Dentro da pasta alugueasy-mcp/
pip install fastmcp python-dotenv
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env
# Edite o .env e ajuste ALUGUEASY_PROJECT_ROOT para o caminho do seu projeto
```

No Windows, o caminho ficará assim no `.env`:
```
ALUGUEASY_PROJECT_ROOT=C:\Users\arthu\OneDrive\Documentos\Alugueasy tarefas
```

### 3. Registrar no Claude Code

Copie o `claude.json` para a raiz do seu projeto Alugueasy:

```bash
cp claude.json ../claude.json
```

Ou registre manualmente via CLI:
```bash
claude mcp add alugueasy-mcp python server.py
```

---

## Testando o servidor

```bash
# Inicia o servidor
python server.py

# Em outro terminal, testa com curl
curl http://localhost:8000/mcp/tools/list
```

---

## Prompts para o Claude Code (copie e envie na ordem)

### FASE 1 — Setup do ambiente

```
Prompt 1:
Leia o arquivo server.py do MCP e confirme que as dependências fastmcp e python-dotenv
estão instaladas. Se não estiverem, instale-as com pip. Depois, verifique se o arquivo
.env existe e se ALUGUEASY_PROJECT_ROOT aponta para um diretório válido.
```

```
Prompt 2:
Execute o servidor MCP com `python server.py` em background e confirme que está
respondendo em http://localhost:8000. Faça um request de teste para listar as tools
disponíveis e mostre o resultado.
```

### FASE 2 — Análise do codebase

```
Prompt 3:
Use a tool list_components() do MCP para listar todos os componentes React do projeto.
Em seguida, identifique os 5 componentes com maior tamanho em bytes e liste-os
ordenados do maior para o menor. Esses serão os candidatos prioritários para refatoração.
```

```
Prompt 4:
Use a tool get_project_context() para carregar a documentação do projeto.
Depois use get_db_schema() para ler o schema do banco.
Com base nesses dados, identifique: quais features da documentação ainda não foram
implementadas (marcadas como "Não implementado") e priorize-as por impacto no usuário.
```

```
Prompt 5:
Use a tool read_file('src/app/components/Dashboard.tsx') para ler o Dashboard.
Em seguida, aplique o prompt review_component com component_name='Dashboard' e
component_path='src/app/components/Dashboard.tsx'. Gere um relatório completo
de melhorias e salve em REVIEW_Dashboard.md na raiz do projeto.
```

### FASE 3 — Melhorias concretas

```
Prompt 6:
Com base na revisão do Dashboard, implemente a melhoria de maior impacto e menor
risco. Use TypeScript estrito, siga os padrões de cores do Alugueasy (#1E3A5F navy,
#A8B4C0 slate, #F4F6F9 background) e mantenha compatibilidade com Tailwind CSS v4.
Mostre o diff antes/depois.
```

```
Prompt 7:
Use o prompt audit_security() do MCP para auditar o projeto inteiro.
Foque especialmente em: (1) variáveis de ambiente expostas, (2) RLS do Supabase,
(3) validação de inputs nos formulários de criação de tarefa.
Gere um relatório SECURITY_AUDIT.md com severidade e correções.
```

```
Prompt 8:
Analise o arquivo src/lib/supabase.ts com read_file().
Identifique todas as queries que podem causar o problema N+1 (múltiplas queries
para buscar dados relacionados). Proponha a versão otimizada usando joins do Supabase
e salve as correções diretamente no arquivo.
```

### FASE 4 — Novas features

```
Prompt 9:
Use o prompt suggest_feature com:
  feature_name = 'Sistema de Automações'
  feature_description = 'Quando o status de uma tarefa mudar para Concluído,
  mover automaticamente para o grupo Arquivo e notificar o responsável via toast.
  Quando a data de vencimento passar sem o status ser Concluído, mudar a prioridade
  automaticamente para Crítica.'
Gere o schema SQL, o hook React e o componente de configuração de automações.
```

```
Prompt 10:
Leia os componentes de visualização Kanban e Tabela com read_file().
Compare os dois e identifique código duplicado. Extraia a lógica comum para um hook
customizado useTaskFilters() e refatore ambos os componentes para usá-lo.
Mantenha todos os tipos TypeScript existentes.
```

### FASE 5 — Deploy e testes

```
Prompt 11:
Configure o servidor MCP para iniciar automaticamente com o projeto.
Adicione um script "mcp:start" no package.json que inicia o servidor Python em background
antes do servidor de desenvolvimento Vite. Use concurrently ou similar para rodar ambos.
```

```
Prompt 12:
Escreva testes unitários para as 3 tools mais críticas do MCP server:
read_file(), list_components() e get_db_schema(). Use pytest.
Garanta cobertura de: caminho válido, caminho com path traversal (segurança),
arquivo não encontrado e extensão não permitida.
```

---

## Estrutura do servidor

```
alugueasy-mcp/
├── server.py          ← Servidor MCP principal
├── .env.example       ← Template de variáveis de ambiente
├── .env               ← Suas variáveis (não commitado no git)
├── claude.json        ← Configuração para Claude Code
└── README.md          ← Este arquivo
```

---

## Segurança

- O servidor nunca expõe arquivos fora do PROJECT_ROOT
- Diretórios proibidos: .git, node_modules, dist, build
- Apenas extensões de código são legíveis (.ts, .tsx, .js, .jsx, .css, .json, .md, .sql)
- Arquivos maiores que 100KB são bloqueados
- Path traversal (../../) é detectado e bloqueado

---

## Roadmap

- [ ] Autenticação por token no header HTTP
- [ ] Tool write_file() para aplicar melhorias diretamente (requer confirmação)
- [ ] Resource alugueasy://git-diff para ver mudanças recentes
- [ ] Integração com Supabase Management API para aplicar migrações
- [ ] Rate limiting por tool
